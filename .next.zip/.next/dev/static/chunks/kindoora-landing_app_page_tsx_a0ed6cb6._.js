(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/6ee64_next_dist_5bd24922._.js",
  "static/chunks/kindoora-landing_app_components_FAQ_tsx_5523cb3a._.js"
],
    source: "dynamic"
});
