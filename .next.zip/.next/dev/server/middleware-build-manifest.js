globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/6ee64_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e01d73fc._.js",
    "static/chunks/6ee64_next_dist_compiled_react-dom_b7553dea._.js",
    "static/chunks/6ee64_next_dist_compiled_react-server-dom-turbopack_3c7be789._.js",
    "static/chunks/6ee64_next_dist_compiled_next-devtools_index_71681c94.js",
    "static/chunks/6ee64_next_dist_compiled_9d454672._.js",
    "static/chunks/6ee64_next_dist_client_dd03c09c._.js",
    "static/chunks/6ee64_next_dist_beec94c7._.js",
    "static/chunks/6ee64_@swc_helpers_cjs_65198580._.js",
    "static/chunks/kindoora-landing_a0ff3932._.js",
    "static/chunks/turbopack-kindoora-landing_b3ea0fe4._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];