module.exports=[42341,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},48305,a=>{"use strict";let b={src:a.i(42341).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=kindoora-landing_app_6e41293d._.js.map