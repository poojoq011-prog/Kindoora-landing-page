module.exports = [
"[project]/kindoora-landing/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kindoora-landing__next-internal_server_app_page_actions_f575cf99.js.map