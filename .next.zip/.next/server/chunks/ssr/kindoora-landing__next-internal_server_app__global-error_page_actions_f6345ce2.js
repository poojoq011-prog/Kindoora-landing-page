module.exports=[70791,(a,b,c)=>{}];

//# sourceMappingURL=kindoora-landing__next-internal_server_app__global-error_page_actions_f6345ce2.js.map