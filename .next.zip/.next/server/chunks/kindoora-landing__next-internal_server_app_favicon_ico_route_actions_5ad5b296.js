module.exports=[99708,(e,o,d)=>{}];

//# sourceMappingURL=kindoora-landing__next-internal_server_app_favicon_ico_route_actions_5ad5b296.js.map