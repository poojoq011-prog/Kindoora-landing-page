module.exports=[23413,(a,b,c)=>{}];

//# sourceMappingURL=kindoora-landing__next-internal_server_app_page_actions_f575cf99.js.map