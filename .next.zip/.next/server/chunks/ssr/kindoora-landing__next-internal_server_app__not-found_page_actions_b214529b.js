module.exports=[65075,(a,b,c)=>{}];

//# sourceMappingURL=kindoora-landing__next-internal_server_app__not-found_page_actions_b214529b.js.map